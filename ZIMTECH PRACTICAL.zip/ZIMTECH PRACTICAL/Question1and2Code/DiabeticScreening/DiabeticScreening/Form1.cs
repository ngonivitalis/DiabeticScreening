using System.Text;
using System.Windows.Forms;

namespace DiabeticScreening
{
    public class details
    {
        public int systolic { get; set; }
        public int diastolic { get; set; }
        public double weight { get; set; }  
        public double height { get; set; }  
        public int age { get; set; }    


    }
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

          


            StringBuilder bloodpressure=new StringBuilder();
            StringBuilder bodymass = new StringBuilder();
            int Systolic, Diastolic,age;
            double kg, meters;
            String bp = null;
            String bm = null;
            //Checking if all fields  have data
            if (txtSystolic.Text != "" & txtDiastolic.Text != "" & txtKg.Text != "" & txtMeters.Text != "" & txtage.Text!="")
            {
              

                //
                Systolic = int.Parse(txtSystolic.Text);   
                Diastolic = int.Parse(txtDiastolic.Text);
                kg = double.Parse(txtKg.Text);
                meters = double.Parse(txtMeters.Text);
                age = int.Parse(txtage.Text);

                // Creating an instance for each record and saving it as CSV in file local path
                var patients = new List<details>() {
                new details(){ systolic   = Systolic, diastolic =Diastolic,weight=kg,height=meters,age=age}
            };

                //Creating CSV COLUMN NAMES 
                var csv = new StringBuilder();
                var newLine0 = string.Format("{0},{1},{2},{3},{4},{5},{6}", "Systolic", "Diastolic", "Weight", "Height", "Age","BloodPressure","BodyMass");
                csv.AppendLine(newLine0);


                //Calculate Blood Pressure
                bloodpressure.Append("Blood Pressure");
                if ((Systolic < 120) & (Diastolic<80)) {
                    bloodpressure.Append("\n NORMAL");
                }
                else if ((120<=Systolic & Systolic <= 129) & (Diastolic<80)) { bloodpressure.Append("\n ELEVATED");bp = "ELEVATED"; }
                else if ((130<= Systolic & Systolic<= 139) |(80 <= Diastolic & Diastolic <= 89)) { bloodpressure.Append("\n HIGH BLOOD PRESSURE (HYPERTENSION) STAGE 1"); bp = "HIGH BLOOD PRESSURE (HYPERTENSION) STAGE 1"; }
                //Add a condition to Limit the range for (HYPERTENSION) STAGE 2") inorder to make HYPERTENSIVE CRISIS Accessible
                else if ((140<= Systolic & Systolic<= 180) | (90 <= Diastolic & Diastolic<=120)) { bloodpressure.Append("\n HIGH BLOOD PRESSURE (HYPERTENSION) STAGE 2"); bp = "HIGH BLOOD PRESSURE (HYPERTENSION) STAGE 2"; }
                else if ((180<Systolic) & (120<Diastolic)) { bloodpressure.Append("\n HYPERTENSIVE CRISIS (consult your doctor immediately)"); bp = "HYPERTENSIVE CRISIS (consult your doctor immediately)"; }
                else if ((180 < Systolic) | (120 < Diastolic)) { bloodpressure.Append("\n HYPERTENSIVE CRISIS (consult your doctor immediately)"); bp = "HYPERTENSIVE CRISIS (consult your doctor immediately)"; }

                richTextBox1.AppendText(bloodpressure.ToString());

                //Calculate Body Mass
                bodymass.Append("\n Body Mass");


                double BMI = kg / ((meters / 100.0) * (meters / 100.0));
                double bmi = Math.Round(BMI, 1);
                if ((18.5 <= BMI & BMI <= 24.9) & (18 <= age & age <= 65))
                {
                    bodymass.Append("\n " + bmi + " is Considered aHealthy Weight");

                    bm = "Healthy";
                }
                else if (25.0 <= BMI & (18 <= age & age <= 65)) { bodymass.Append("\n " + bmi + " is Considered Over Weight");bm = "OverWeight"; }
                richTextBox1.AppendText(bodymass.ToString());

                //Save in CSV file
                foreach (details item in patients)
                {
                    var newLine = string.Format("{0},{1},{2},{3},{4},{5},{6}", Systolic, Diastolic, kg, meters, age, bp, bm);
                    csv.AppendLine(newLine);
                    
                }
                //Ammend File Path before running
                File.WriteAllText(@"C:\Users\nvitalis\Desktop\ZIMTECH PRACTICAL\vtalis.csv", csv.ToString());

            }
            else
            {
                MessageBox.Show("Enter all valid Details", "Error");
            }

           


        }

        private void button2_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }
    }
}